from opt import args
from utils import load_graph_data, laplacian_filtering
import numpy as np

def setup_args(dataset_name="cora", use_adaptive_confidence=False):
    args.dataset = dataset_name
    args.device = "cuda:0"
    args.acc = args.nmi = args.ari = args.f1 = 0
    args.alpha_value = 0.2


    if args.dataset == 'cora':
        args.t = 5
        args.lr = 1e-3
        args.n_input = 500
        args.dims = 1500
        args.activate = 'ident'
        args.tao = 0.2
        args.beta = 1
        args.gamma = 8

    elif args.dataset == 'citeseer':
        args.t = 6
        args.lr = 1e-3
        args.n_input = 400
        args.dims = 1500
        args.activate = 'sigmoid'
        args.tao = 0.1
        args.beta = 2
        args.gamma = 5

    elif args.dataset == 'amap':
        args.t = 3
        args.lr = 1e-5
        args.n_input = -1
        args.dims = 500
        args.activate = 'ident'
        args.tao = 0.9
        args.beta = 3

    elif args.dataset == 'bat':
        args.t = 5
        args.lr = 1e-3
        args.n_input = -1
        args.dims = 1500
        args.activate = 'ident'
        args.tao = 0.2
        args.beta = 5
        args.gamma = 1

    elif args.dataset == 'dblp':
        args.t = 1
        args.lr = 1e-3
        args.n_input = -1
        args.dims = 1500
        args.activate = 'ident'
        args.tao = 0.6
        args.beta = 5
        args.gamma = 8

    elif args.dataset == 'acm':
        args.t = 1
        args.lr = 1e-3
        args.n_input = -1
        args.dims = 1500
        args.activate = 'ident'
        args.tao = 0.6
        args.beta = 5
        args.gamma = 2        

    elif args.dataset == 'eat':
        args.t = 6
        args.lr = 1e-4
        args.n_input = -1
        args.dims = 1500
        args.activate = 'ident'
        args.tao = 0.7
        args.beta = 5

    elif args.dataset == 'uat':
        args.t = 6
        args.lr = 1e-4
        args.n_input = -1
        args.dims = 500
        args.activate = 'sigmoid'
        args.tao = 0.7
        args.beta = 5

    # other new datasets
    else:
        args.t = 2
        args.lr = 1e-3
        args.n_input = 500
        args.dims = 1500
        args.activate = 'ident'
        args.tao = 0.9
        args.beta = 1



    print("---------------------")
    print("runs: {}".format(args.runs))
    print("dataset: {}".format(args.dataset))
    print("confidence: {}".format(args.tao))
    print("focusing factor: {}".format(args.beta))
    print("learning rate: {}".format(args.lr))
    print("---------------------")

    return args



