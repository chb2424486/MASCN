import torch
from opt import args
import torch.nn as nn
import torch.nn.functional as F


class hard_sample_aware_network(nn.Module):
    def __init__(self, input_dim, hidden_dim, act, n_num):
        super(hard_sample_aware_network, self).__init__()
        self.AE1 = nn.Linear(input_dim, hidden_dim)
        self.AE2 = nn.Linear(input_dim, hidden_dim)

        self.SE1 = nn.Linear(n_num, hidden_dim)
        self.SE2 = nn.Linear(n_num, hidden_dim)

        self.alpha = nn.Parameter(torch.Tensor(1, ))
        self.alpha.data = torch.tensor(0.99999).to(args.device)

        self.pos_weight = torch.ones(n_num * 2).to(args.device)
        self.pos_neg_weight = torch.ones([n_num * 2, n_num * 2]).to(args.device)

        if act == "ident":
            self.activate = lambda x: x
        if act == "sigmoid":
            self.activate = nn.Sigmoid()

    def forward(self, X_filtered, X_gaosi, A_remove, Ad):
        Z1 = self.activate(self.AE1(X_filtered))
        Z2 = self.activate(self.AE2(X_gaosi))

        Z1 = F.normalize(Z1, dim=1, p=2)
        Z2 = F.normalize(Z2, dim=1, p=2)

        E1 = F.normalize(self.SE1(A_remove), dim=1, p=2)
        E2 = F.normalize(self.SE2(Ad), dim=1, p=2)

        return Z1, Z2, E1, E2



class GCNLayer(nn.Module):
    """单层图卷积网络层"""
    def __init__(self, in_features, out_features, dropout=0.1, bias=True):
        super(GCNLayer, self).__init__()
        self.in_features = in_features
        self.out_features = out_features
        
        # 权重矩阵
        self.weight = nn.Parameter(torch.FloatTensor(in_features, out_features))
        if bias:
            self.bias = nn.Parameter(torch.FloatTensor(out_features))
        else:
            self.register_parameter('bias', None)
            
        self.dropout = nn.Dropout(dropout)
        self.reset_parameters()
        
    def reset_parameters(self):
        """初始化参数"""
        nn.init.xavier_uniform_(self.weight)
        if self.bias is not None:
            nn.init.zeros_(self.bias)
            
    def forward(self, input, adj):
        # 应用dropout
        input = self.dropout(input)
        
        # 特征变换: XW
        support = torch.mm(input, self.weight)
        
        # 图卷积: AXW
        output = torch.spmm(adj, support) if adj.is_sparse else torch.mm(adj, support)
        
        # 添加偏置
        if self.bias is not None:
            output = output + self.bias
            
        return output


def normalize_adj_matrix(adj, self_loop=True):
    """归一化邻接矩阵"""
    if self_loop:
        # 添加自环
        adj = adj + torch.eye(adj.size(0), device=adj.device)
    
    # 计算度矩阵
    rowsum = adj.sum(1)
    d_inv_sqrt = torch.pow(rowsum, -0.5).flatten()
    d_inv_sqrt[torch.isinf(d_inv_sqrt)] = 0.
    d_mat_inv_sqrt = torch.diag(d_inv_sqrt)
    
    # 对称归一化: D^(-1/2) * A * D^(-1/2)
    normalized_adj = torch.mm(torch.mm(d_mat_inv_sqrt, adj), d_mat_inv_sqrt)
    
    return normalized_adj


class ClusterGCN(nn.Module):
    def __init__(self, input_dim, cluster_num, hidden_dim=None, dropout=0.1, num_layers=2):
        super(ClusterGCN, self).__init__()
        self.input_dim = input_dim
        self.cluster_num = cluster_num
        self.num_layers = num_layers
        
        # 如果没有指定隐藏层维度，使用输入维度和输出维度的平均值
        if hidden_dim is None:
            hidden_dim = (input_dim + cluster_num) // 2
        
        self.layers = nn.ModuleList()
        
        if num_layers == 1:
            # 单层直接映射
            self.layers.append(GCNLayer(input_dim, cluster_num, dropout))
        else:
            # 多层GCN
            # 第一层
            self.layers.append(GCNLayer(input_dim, hidden_dim, dropout))
            
            # 中间层
            for _ in range(num_layers - 2):
                self.layers.append(GCNLayer(hidden_dim, hidden_dim, dropout))
            
            # 输出层
            self.layers.append(GCNLayer(hidden_dim, cluster_num, dropout))
        
        self.dropout = nn.Dropout(dropout)
        
    def forward(self, h, adj):
        # 归一化邻接矩阵
        adj_norm = normalize_adj_matrix(adj)
        
        x = h
        for i, layer in enumerate(self.layers):
            x = layer(x, adj_norm)
            
            # 除了最后一层，都应用激活函数和dropout
            if i < len(self.layers) - 1:
                x = F.leaky_relu(x)
                x = self.dropout(x)
        
        return x


class DualViewClusterGCN(nn.Module):
    """双视图聚类GCN模块"""
    def __init__(self, input_dim, cluster_num, hidden_dim=None, dropout=0.1, num_layers=2, act="ident"):
        super(DualViewClusterGCN, self).__init__()
        self.gcn1 = ClusterGCN(input_dim, cluster_num, hidden_dim, dropout, num_layers)
        self.gcn2 = ClusterGCN(input_dim, cluster_num, hidden_dim, dropout, num_layers)
        self.ae = nn.Linear(cluster_num, cluster_num)

        if act == "ident":
            self.activate = lambda x: x
        if act == "sigmoid":
            self.activate = nn.Sigmoid()
        
    def forward(self, z1, z2, adj):

        cluster_z1 = self.gcn1(z1, adj)
        cluster_z1 = self.activate(self.ae(cluster_z1))
        cluster_z1 = F.normalize(cluster_z1, dim=1, p=2)

        cluster_z2 = self.gcn2(z2, adj)
        cluster_z2 = self.activate(self.ae(cluster_z2))
        cluster_z2 = F.normalize(cluster_z2, dim=1, p=2)
        

        return cluster_z1, cluster_z2
